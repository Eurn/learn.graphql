const { ApolloServer, gql } = require("apollo-server");
const { GraphQLScalarType, Kind } = require("graphql");

const users = [
  {
    id: 1,
    email: "test@gmail.com",
    password: "pwd",
    firstName: "Jack",
    lastName: "Marcus",
    pseudo: "JM",
  },
  {
    id: 2,
    email: "test2@gmail.com",
    password: "pwd2",
    firstName: "Martin",
    lastName: "James",
    pseudo: "MJ",
  },
];

const posts = [
  {
    id: 1,
    author: {
      id: 1,
      email: "test@gmail.com",
      password: "pwd",
      firstName: "Jack",
      lastName: "Marcus",
      pseudo: "JM",
    },
    content: "voici un magnifique post",
    comments: [
      {
        id: 2,
        author: {
          id: 2,
          email: "test2@gmail.com",
          password: "pwd2",
          firstName: "Martin",
          lastName: "James",
          pseudo: "MJ",
        },
        content: "Ton post est nul! menteur",
        comments: [
          {
            id: 1,
            author: {
              id: 1,
              email: "test@gmail.com",
              password: "pwd",
              firstName: "Jack",
              lastName: "Marcus",
              pseudo: "JM",
            },
            content: "JALOUSIE",
            comments: [],
            createdAt: "2010-10-11",
            updatedAt: null,
          },
        ],
        createdAt: "2010-10-11",
        updatedAt: null,
      },
    ],
    createdAt: "2010-10-11",
    updatedAt: null,
  },
  {
    id: 2,
    author: {
      id: 1,
      email: "test@gmail.com",
      password: "pwd",
      firstName: "Jack",
      lastName: "Marcus",
      pseudo: "JM",
    },
    content: "Mon deuxieème post",
    comments: [],
    createdAt: "2010-10-13",
    updatedAt: null,
  },
];

const typeDefs = gql`
  scalar Date

  type User {
    id: ID!
    email: String!
    password: String!
    firstName: String
    lastName: String
    pseudo: String
  }

  type Post {
    id: ID!
    author: User!
    content: String!
    comments: [Post]
    createdAt: Date
    updatedAt: Date
  }

  input AddUser {
    email: String!
    password: String!
    firstName: String
    lastName: String
    pseudo: String
  }

  input AddPost {
    author: AddUser!
    content: String!
    comments: [AddPost]
    createdAt: Date
    updatedAt: Date
  }

  type Query {
    users: [User]
    posts: [Post]
    hello: String
  }

  type Mutation {
    addPost(input: AddPost!): Post!
  }
`;

const dateScalar = new GraphQLScalarType({
  name: "Date",
  description: "Date custom scalar type",
  serialize(value) {
    return value.getTime(); // Convert outgoing Date to integer for JSON
  },
  parseValue(value) {
    return new Date(value); // Convert incoming integer to Date
  },
  parseLiteral(ast) {
    if (ast.kind === Kind.INT) {
      return new Date(parseInt(ast.value, 10)); // Convert hard-coded AST string to integer and then to Date
    }
    return null; // Invalid hard-coded value (not an integer)
  },
});

const resolvers = {
  Date: dateScalar,
  Query: {
    users: () => users,
    posts: () => posts,
    hello: () => "hello world",
  },
  Mutation: {
    addPost: (parent, { author, User, content }) => {
      let newPost = { author, User, content };
      posts.push(newPost);
      return newPost;
    },
  },
};

const server = new ApolloServer({ typeDefs, resolvers });
server.listen().then(({ url }) => {
  console.log(`🚀  Server ready at ${url}`);
});
